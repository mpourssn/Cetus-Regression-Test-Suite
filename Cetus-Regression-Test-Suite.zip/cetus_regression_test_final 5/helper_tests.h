#ifndef HELPER_TESTS_H
#define HELPER_TESTS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <sys/stat.h>
#include <sys/wait.h>

// Configuration Constants for common use
#define MAX_PATH_LENGTH 1024
#define CLANG_PATH "/opt/homebrew/opt/llvm/bin/clang" // Adjust if your clang path is different
#define CETUS_PATH "./cetus" // Path to the Cetus executable. Adjust as needed

// Define the suffix for ground truth files (e.g., "_gt.c")
// This is critical for your use case!
#define GROUND_TRUTH_SUFFIX "_gt.c"

// Test Mode Enum
typedef enum {
    COMPARE_MODE,
    GENERATE_MODE
} TestMode;

// Expected Parallelization Behavior Enum
typedef enum {
    EXPECT_PARALLELIZATION,
    EXPECT_NO_PARALLELIZATION,
    EXPECT_FAILURE
} ExpectedParallelization;

// Test Outcome Enum
typedef enum {
    TEST_PASSED,
    TEST_FAILED_CRASH,
    TEST_FAILED_DIFF,
    TEST_FAILED_PREPROCESS,
    TEST_FAILED_SEMANTIC_CHECK,
    TEST_FAILED_MKDIR,
    TEST_FAILED_COPY_GROUND_TRUTH,
    TEST_FAILED_MISSING_OUTPUT,
    TEST_FAILED_MISSING_GROUND_TRUTH,
    TEST_FAILED_NO_EXTENSION,
    TEST_FAILED_UNKNOWN,
    TEST_FAILED_MISSED_OPPORTUNITY,
    TEST_FAILED_INCORRECT_PARALLELIZATION
} TestOutcome;

// Global Log File Pointers (declared here, defined in main .c file)
extern FILE *log_all_fp;
extern FILE *log_passed_fp;
extern FILE *log_failed_fp;
extern FILE *log_crashes_fp;
extern FILE *log_missed_opportunities_fp;
extern FILE *log_incorrect_parallelization_fp;

// Helper Function Declarations
char* get_current_time();
long file_size(const char *filename);
int execute_command(const char *command);
void log_test_outcome(TestOutcome outcome, const char* category, const char* input_file_base_name,
                      const char* reason_message, const char* command_executed);

#endif // HELPER_TESTS_H