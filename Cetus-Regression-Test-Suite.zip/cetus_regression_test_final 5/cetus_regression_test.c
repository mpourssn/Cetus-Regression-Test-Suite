#include "helper_tests.h"

// Global Log File Pointers (definitions)
FILE *log_all_fp = NULL;
FILE *log_passed_fp = NULL;
FILE *log_failed_fp = NULL;
FILE *log_crashes_fp = NULL;
FILE *log_missed_opportunities_fp = NULL;
FILE *log_incorrect_parallelization_fp = NULL;

// --- Helper Function Implementations (Moved from .h to .c) ---
// These implementations are now here, ensuring they are only compiled once.

char* get_current_time() {
    static char time_str[20];
    time_t timer;
    struct tm* tm_info;
    time(&timer);
    tm_info = localtime(&timer);
    strftime(time_str, sizeof(time_str), "%Y-%m-%d %H:%M:%S", tm_info);
    return time_str;
}

long file_size(const char *filename) {
    struct stat st;
    if (stat(filename, &st) == 0)
        return st.st_size;
    return -1;
}

int execute_command(const char *command) {
    printf("[%s] DEBUG: Executing command: %s\n", get_current_time(), command);
    if (log_all_fp) fprintf(log_all_fp, "[%s] DEBUG: Executing command: %s\n", get_current_time(), command);

    int result = system(command);

    if (result == -1) {
        fprintf(stderr, "[%s] ERROR: Failed to execute command: %s (System call failed).\n", get_current_time(), command);
        if (log_all_fp) fprintf(log_all_fp, "[%s] ERROR: Failed to execute command: %s (System call failed).\n", get_current_time(), command);
        return -1;
    }

    if (WIFEXITED(result)) {
        int exit_status = WEXITSTATUS(result);
        printf("[%s] Command exited with status: %d\n", get_current_time(), exit_status);
        if (log_all_fp) fprintf(log_all_fp, "[%s] Command exited with status: %d\n", get_current_time(), exit_status);
        return exit_status;
    } else {
        if (WIFSIGNALED(result)) {
            int signal_num = WTERMSIG(result);
            fprintf(stderr, "[%s] ERROR: Command terminated by signal %d: %s\n", get_current_time(), signal_num, command);
            if (log_all_fp) fprintf(log_all_fp, "[%s] ERROR: Command terminated by signal %d: %s\n", get_current_time(), signal_num, command);
        } else {
            fprintf(stderr, "[%s] ERROR: Command did not terminate normally (unknown reason): %s\n", get_current_time(), command);
            if (log_all_fp) fprintf(log_all_fp, "[%s] ERROR: Command did not terminate normally (unknown reason): %s\n", get_current_time(), command);
        }
        return -999;
    }
}

void log_test_outcome(TestOutcome outcome, const char* category, const char* input_file_base_name,
                      const char* reason_message, const char* command_executed) {
    FILE* target_fp = NULL;
    const char* outcome_str = "UNKNOWN";

    switch (outcome) {
        case TEST_PASSED: target_fp = log_passed_fp; outcome_str = "PASSED"; break;
        case TEST_FAILED_CRASH: target_fp = log_crashes_fp; outcome_str = "CRASHED"; break;
        case TEST_FAILED_DIFF: target_fp = log_failed_fp; outcome_str = "DIFF_MISMATCH"; break;
        case TEST_FAILED_PREPROCESS: target_fp = log_failed_fp; outcome_str = "PREPROCESS_FAILED"; break;
        case TEST_FAILED_SEMANTIC_CHECK: target_fp = log_failed_fp; outcome_str = "SEMANTIC_CHECK_FAILED"; break;
        case TEST_FAILED_MKDIR: target_fp = log_failed_fp; outcome_str = "MKDIR_FAILED"; break;
        case TEST_FAILED_COPY_GROUND_TRUTH: target_fp = log_failed_fp; outcome_str = "COPY_GROUND_TRUTH_FAILED"; break;
        case TEST_FAILED_MISSING_OUTPUT: target_fp = log_failed_fp; outcome_str = "MISSING_OUTPUT"; break;
        case TEST_FAILED_MISSING_GROUND_TRUTH: target_fp = log_failed_fp; outcome_str = "MISSING_GROUND_TRUTH"; break;
        case TEST_FAILED_NO_EXTENSION: target_fp = log_failed_fp; outcome_str = "NO_EXTENSION"; break;
        case TEST_FAILED_MISSED_OPPORTUNITY: target_fp = log_missed_opportunities_fp; outcome_str = "MISSED_OPPORTUNITY"; break;
        case TEST_FAILED_INCORRECT_PARALLELIZATION: target_fp = log_incorrect_parallelization_fp; outcome_str = "INCORRECT_PARALLELIZATION"; break;
        case TEST_FAILED_UNKNOWN: default: target_fp = log_failed_fp; outcome_str = "UNKNOWN_FAILURE"; break;
    }

    if (log_all_fp) {
        fprintf(log_all_fp, "[%s] TEST: %s/%s - OUTCOME: %s\n", get_current_time(), category, input_file_base_name, outcome_str);
        if (reason_message && strlen(reason_message) > 0) { fprintf(log_all_fp, "[%s] REASON: %s\n", get_current_time(), reason_message); }
        if (command_executed && strlen(command_executed) > 0) { fprintf(log_all_fp, "[%s] COMMAND: %s\n", get_current_time(), command_executed); }
        fprintf(log_all_fp, "---------------------------------\n\n");
    }

    if (target_fp && target_fp != log_all_fp) {
        fprintf(target_fp, "[%s] TEST: %s/%s - OUTCOME: %s\n", get_current_time(), category, input_file_base_name, outcome_str);
        if (reason_message && strlen(reason_message) > 0) { fprintf(target_fp, "[%s] REASON: %s\n", get_current_time(), reason_message); }
        if (command_executed && strlen(command_executed) > 0) { fprintf(target_fp, "[%s] COMMAND: %s\n", get_current_time(), command_executed); }
        fprintf(target_fp, "---------------------------------\n\n");
    }

    if (outcome != TEST_PASSED) {
        fprintf(stderr, "\n--- TEST FAILED ---\n");
        fprintf(stderr, "TEST: %s/%s\n", category, input_file_base_name);
        fprintf(stderr, "[%s] OUTCOME: %s\n", get_current_time(), outcome_str);
        if (reason_message && strlen(reason_message) > 0) { fprintf(stderr, "[%s] REASON: %s\n", get_current_time(), reason_message); }
        if (command_executed && strlen(command_executed) > 0) { fprintf(stderr, "[%s] COMMAND: %s\n", get_current_time(), command_executed); }
        fprintf(stderr, "---------------------------------\n\n");
    }
}


// --- Main Test Logic Function ---

int run_test_case(const char* category, const char* input_file_base_name, TestMode mode, ExpectedParallelization expected_behavior) {
    char input_file_full_path[MAX_PATH_LENGTH];
    char input_file_base_name_i[MAX_PATH_LENGTH]; // e.g., "my_test.i"
    char input_file_base_name_no_ext[MAX_PATH_LENGTH]; // e.g., "my_test" (without .c)

    const char* intermediate_i_root_dir = "cetus_intermediate_i_files";
    const char* transformed_output_root_dir = "cetus_transformed_output"; // This is where we want output ultimately

    char current_intermediate_i_dir[MAX_PATH_LENGTH];
    char current_transformed_output_dir[MAX_PATH_LENGTH]; // Directory for our desired output

    snprintf(current_intermediate_i_dir, sizeof(current_intermediate_i_dir), "%s/%s", intermediate_i_root_dir, category);
    snprintf(current_transformed_output_dir, sizeof(current_transformed_output_dir), "%s/%s", transformed_output_root_dir, category);

    char mkdir_cmd[MAX_PATH_LENGTH * 2];
    int cmd_result;

    // Create directories for our internal test structure
    snprintf(mkdir_cmd, sizeof(mkdir_cmd), "mkdir -p \"%s\"", current_intermediate_i_dir);
    cmd_result = execute_command(mkdir_cmd);
    if (cmd_result != 0) {
        log_test_outcome(TEST_FAILED_MKDIR, category, input_file_base_name,
                         "Failed to create intermediate .i files directory.", mkdir_cmd);
        return 0;
    }

    snprintf(mkdir_cmd, sizeof(mkdir_cmd), "mkdir -p \"%s\"", current_transformed_output_dir);
    cmd_result = execute_command(mkdir_cmd);
    if (cmd_result != 0) {
        log_test_outcome(TEST_FAILED_MKDIR, category, input_file_base_name,
                         "Failed to create transformed output directory.", mkdir_cmd);
        return 0;
    }

    snprintf(input_file_full_path, sizeof(input_file_full_path), "input_files/%s/%s", category, input_file_base_name);

    char *dot = strrchr(input_file_base_name, '.');
    if (dot != NULL) {
        size_t base_len = dot - input_file_base_name;
        snprintf(input_file_base_name_i, sizeof(input_file_base_name_i), "%.*s.i", (int)base_len, input_file_base_name);
        snprintf(input_file_base_name_no_ext, sizeof(input_file_base_name_no_ext), "%.*s", (int)base_len, input_file_base_name); // Get "my_test"
    } else {
        log_test_outcome(TEST_FAILED_NO_EXTENSION, category, input_file_base_name,
                         "Input file has no extension. Cannot derive .i/.c names.", NULL);
        return 0;
    }

    char preprocessed_input_file[MAX_PATH_LENGTH];
    char cetus_actual_output_file[MAX_PATH_LENGTH]; // This will store where Cetus *actually* puts its output
    char ground_truth_file_path[MAX_PATH_LENGTH];
    char preprocessor_command[MAX_PATH_LENGTH * 2];
    char cetus_command[MAX_PATH_LENGTH * 2];
    char semantic_check_command[MAX_PATH_LENGTH * 2];
    char diff_command[MAX_PATH_LENGTH * 2];

    // --- Preprocessing Step ---
    snprintf(preprocessed_input_file, sizeof(preprocessed_input_file), "%s/%s", current_intermediate_i_dir, input_file_base_name_i);
    printf("[%s] DEBUG: Preprocessing output will be in: %s\n", get_current_time(), preprocessed_input_file);
    if (log_all_fp) fprintf(log_all_fp, "[%s] DEBUG: Preprocessing output will be in: %s\n", get_current_time(), preprocessed_input_file);
    snprintf(preprocessor_command, sizeof(preprocessor_command), "%s -E -P -x c -std=c11 \"%s\" -o \"%s\"", CLANG_PATH, input_file_full_path, preprocessed_input_file);

    printf("[%s] Manually preprocessing %s to %s...\n", get_current_time(), input_file_full_path, preprocessed_input_file);
    if (log_all_fp) fprintf(log_all_fp, "[%s] Manually preprocessing %s to %s...\n", get_current_time(), input_file_full_path, preprocessed_input_file);
    cmd_result = execute_command(preprocessor_command);
    if (cmd_result != 0) {
        TestOutcome outcome_type = TEST_FAILED_PREPROCESS; char reason_buf[MAX_PATH_LENGTH];
        if (cmd_result == -999) { outcome_type = TEST_FAILED_CRASH; snprintf(reason_buf, sizeof(reason_buf), "Preprocessor CRASHED."); }
        else { snprintf(reason_buf, sizeof(reason_buf), "Preprocessing failed (exit code %d).", cmd_result); }
        log_test_outcome(outcome_type, category, input_file_base_name, reason_buf, preprocessor_command); return 0;
    }
    printf("[%s] Preprocessing successful. Output file: %s (size %ld bytes).\n", get_current_time(), preprocessed_input_file, file_size(preprocessed_input_file));
    if (log_all_fp) fprintf(log_all_fp, "[%s] Preprocessing successful. Output file: %s (size %ld bytes).\n", get_current_time(), preprocessed_input_file, file_size(preprocessed_input_file));


    // --- Semantic Check ---
    snprintf(semantic_check_command, sizeof(semantic_check_command), "./check_syntax.sh \"%s\"", preprocessed_input_file);
    printf("[%s] Running semantic check command: %s\n", get_current_time(), semantic_check_command);
    if (log_all_fp) fprintf(log_all_fp, "[%s] Running semantic check command: %s\n", get_current_time(), semantic_check_command);
    cmd_result = execute_command(semantic_check_command);
    if (cmd_result != 0) {
        TestOutcome outcome_type = TEST_FAILED_SEMANTIC_CHECK; char reason_buf[MAX_PATH_LENGTH];
        if (cmd_result == -999) { outcome_type = TEST_FAILED_CRASH; snprintf(reason_buf, sizeof(reason_buf), "Semantic check script CRASHED."); }
        else { snprintf(reason_buf, sizeof(reason_buf), "Semantic check failed (exit code %d).", cmd_result); }
        log_test_outcome(outcome_type, category, input_file_base_name, reason_buf, semantic_check_command); return 0;
    }
    printf("[%s] Semantic check successful.\n", get_current_time());
    if (log_all_fp) fprintf(log_all_fp, "[%s] Semantic check successful.\n", get_current_time());


    printf("[%s] Applying Cetus transformation: Parallelization\n", get_current_time());
    if (log_all_fp) fprintf(log_all_fp, "[%s] Applying Cetus transformation: Parallelization\n", get_current_time());

    // --- Cetus Execution Step ---
    snprintf(cetus_command, sizeof(cetus_command), "%s -outdir=\"%s\" -parallelize-loops=1 -ompGen=1 \"%s\"", CETUS_PATH, current_transformed_output_dir, preprocessed_input_file);
    printf("[%s] DEBUG: Cetus command: %s\n", get_current_time(), cetus_command);
    if (log_all_fp) fprintf(log_all_fp, "[%s] DEBUG: Cetus command: %s\n", get_current_time(), cetus_command);

    cmd_result = execute_command(cetus_command);
    if (cmd_result != 0) {
        TestOutcome outcome_type = TEST_FAILED_UNKNOWN; char reason_buf[MAX_PATH_LENGTH];
        if (cmd_result == -999) { outcome_type = TEST_FAILED_CRASH; snprintf(reason_buf, sizeof(reason_buf), "Cetus CRASHED (terminated abnormally)."); }
        else { snprintf(reason_buf, sizeof(reason_buf), "Cetus execution failed (returned non-zero exit code %d).", cmd_result); }
        log_test_outcome(outcome_type, category, input_file_base_name, reason_buf, cetus_command); return 0;
    }
    printf("[%s] Cetus execution successful.\n", get_current_time());
    if (log_all_fp) fprintf(log_all_fp, "[%s] Cetus execution successful.\n", get_current_time());

    // --- DETERMINE ACTUAL CETUS OUTPUT FILE PATH ---
    // Cetus is expected to output a .i file because it took a .i file as input.
    snprintf(cetus_actual_output_file, sizeof(cetus_actual_output_file), "%s/%s", current_transformed_output_dir, input_file_base_name_i);
    printf("[%s] DEBUG: Cetus output is expected at: %s\n", get_current_time(), cetus_actual_output_file);
    if (log_all_fp) fprintf(log_all_fp, "[%s] DEBUG: Cetus output is expected at: %s\n", get_current_time(), cetus_actual_output_file);


    // --- Determine Ground Truth File Path (using GROUND_TRUTH_SUFFIX) ---
    // This will now look for e.g., "ground_truth/parallelization/missed_parallelization_gt.c"
    snprintf(ground_truth_file_path, sizeof(ground_truth_file_path), "ground_truth/%s/%s%s", category, input_file_base_name_no_ext, GROUND_TRUTH_SUFFIX);


    // --- Ground Truth Generation or Comparison ---
    if (mode == GENERATE_MODE) {
        printf("[%s] Generating ground truth for %s...\n", get_current_time(), input_file_base_name);
        if (log_all_fp) fprintf(log_all_fp, "[%s] Generating ground truth for %s...\n", get_current_time(), input_file_base_name);
        char ground_truth_category_dir[MAX_PATH_LENGTH];
        snprintf(ground_truth_category_dir, sizeof(ground_truth_category_dir), "ground_truth/%s", category);
        snprintf(mkdir_cmd, sizeof(mkdir_cmd), "mkdir -p \"%s\"", ground_truth_category_dir);
        cmd_result = execute_command(mkdir_cmd);
        if (cmd_result != 0) {
            log_test_outcome(TEST_FAILED_MKDIR, category, input_file_base_name,
                             "Failed to create ground truth category directory.", mkdir_cmd);
            return 0;
        }

        char cp_cmd[MAX_PATH_LENGTH * 2];
        // When generating ground truth, we copy Cetus's *actual* output (.i) to the ground_truth/ directory,
        // and name it with the GROUND_TRUTH_SUFFIX as per ground truth convention.
        snprintf(cp_cmd, sizeof(cp_cmd), "cp \"%s\" \"%s\"", cetus_actual_output_file, ground_truth_file_path);
        cmd_result = execute_command(cp_cmd);
        if (cmd_result != 0) {
            log_test_outcome(TEST_FAILED_COPY_GROUND_TRUTH, category, input_file_base_name,
                             "Failed to generate ground truth (copy command failed). Make sure Cetus produced the file: %s", cetus_actual_output_file);
            return 0;
        }
        printf("[%s] Ground truth generated successfully for %s.\n", get_current_time(), input_file_base_name);
        if (log_all_fp) fprintf(log_all_fp, "[%s] Ground truth generated successfully for %s.\n", get_current_time(), input_file_base_name);
        log_test_outcome(TEST_PASSED, category, input_file_base_name, "Ground truth generated successfully.", NULL);
        return 1;
    } else { // COMPARE_MODE
        printf("[%s] Comparing Cetus output with ground truth for %s...\n", get_current_time(), input_file_base_name);
        if (log_all_fp) fprintf(log_all_fp, "[%s] Comparing Cetus output with ground truth for %s...\n", get_current_time(), input_file_base_name);

        // --- Check for existence of expected Cetus output and Ground Truth ---
        if (access(cetus_actual_output_file, F_OK) != 0) {
            log_test_outcome(TEST_FAILED_MISSING_OUTPUT, category, input_file_base_name,
                             "Cetus did not produce its expected output file: '%s'.", cetus_actual_output_file);
            return 0;
        }

        if (access(ground_truth_file_path, F_OK) != 0) {
            log_test_outcome(TEST_FAILED_MISSING_GROUND_TRUTH, category, input_file_base_name,
                             "Ground truth file not found: '%s'. Please ensure it exists with the correct naming convention ('_gt.c' suffix expected).", ground_truth_file_path);
            return 0; // Exit early if ground truth is missing
        }

        // Get file sizes for heuristic comparison
        long input_file_size = file_size(input_file_full_path);
        long cetus_output_file_size = file_size(cetus_actual_output_file);
        long ground_truth_file_size = file_size(ground_truth_file_path);

        if (input_file_size == -1 || cetus_output_file_size == -1 || ground_truth_file_size == -1) {
            log_test_outcome(TEST_FAILED_UNKNOWN, category, input_file_base_name,
                             "Failed to get file sizes for comparison. Check file existence or permissions.", NULL);
            return 0;
        }

        // Diff Comparison Step
        // We compare Cetus's actual output (.i) with the ground truth (now correctly looking for _gt.c)
        snprintf(diff_command, sizeof(diff_command), "diff -wB \"%s\" \"%s\"", cetus_actual_output_file, ground_truth_file_path);
        printf("[%s] DEBUG: Diff command: %s\n", get_current_time(), diff_command);
        if (log_all_fp) fprintf(log_all_fp, "[%s] DEBUG: Diff command: %s\n", get_current_time(), diff_command);

        int diff_result = execute_command(diff_command);

        if (diff_result != 0) {
            char reason_buf[MAX_PATH_LENGTH];
            TestOutcome outcome_to_log = TEST_FAILED_DIFF;

            // Heuristic for missed parallelization vs incorrect parallelization
            if (expected_behavior == EXPECT_PARALLELIZATION) {
                // If the Cetus output is not significantly larger than the input,
                // and there's a diff, it suggests parallelization was missed.
                // (e.g., if input is 100 bytes, and output is 105 bytes, probably no pragmas added)
                // Threshold of 1.1 (10% increase) is a rough heuristic for "significant" change.
                if (cetus_output_file_size <= (input_file_size * 1.1)) {
                     outcome_to_log = TEST_FAILED_MISSED_OPPORTUNITY;
                     snprintf(reason_buf, sizeof(reason_buf), "Cetus output is different from ground truth, and appears largely unparallelized (size heuristic). Expected parallelization.");
                } else { // Output file is significantly larger, suggesting some transformation occurred
                    outcome_to_log = TEST_FAILED_INCORRECT_PARALLELIZATION;
                    snprintf(reason_buf, sizeof(reason_buf), "Cetus output is different from ground truth. Appears to be incorrect parallelization.");
                }
            } else if (expected_behavior == EXPECT_NO_PARALLELIZATION) {
                outcome_to_log = TEST_FAILED_INCORRECT_PARALLELIZATION;
                snprintf(reason_buf, sizeof(reason_buf), "Cetus output is different from ground truth. No parallelization was expected, but output was changed.");
            } else { // EXPECT_FAILURE (or other general diff)
                 snprintf(reason_buf, sizeof(reason_buf), "Output does NOT match ground truth (Diff found).");
            }

            log_test_outcome(outcome_to_log, category, input_file_base_name, reason_buf, diff_command);
            return 0;
        } else {
            // Diff result is 0, meaning files are identical.
            // Check if this "identical" output is actually what we expected given parallelization goals.
            if (expected_behavior == EXPECT_PARALLELIZATION) {
                // If parallelization was expected, but Cetus produced an output IDENTICAL to the (likely unparallelized) input,
                // and this identical output is also the ground truth (which would be unparallelized), then it's a missed opportunity.
                // This check is a bit tricky: if the ground truth *is* parallelized, but Cetus produced an unparallelized output,
                // the diff would have already caught it. This path means Cetus output matched the ground truth *and* that ground truth implies no parallelization
                // was actually performed (even if expected).
                if (ground_truth_file_size <= (input_file_size * 1.05)) { // Small size change implies no parallelization occurred in ground truth
                    log_test_outcome(TEST_FAILED_MISSED_OPPORTUNITY, category, input_file_base_name,
                                     "Output matches (unparallelized) ground truth, but parallelization was expected.", NULL);
                    return 0;
                }
            }
            printf("[%s] ✅ SUCCESS: %s passed. Output matches ground truth.\n", get_current_time(), input_file_base_name);
            if (log_all_fp) fprintf(log_all_fp, "[%s] SUCCESS: %s passed. Output matches ground truth.\n", get_current_time(), input_file_base_name);
            log_test_outcome(TEST_PASSED, category, input_file_base_name, "Output matches ground truth.", NULL);
            return 1;
        }
    }
}

// --- Main Function ---

int main(int argc, char *argv[]) {
    // Ensure logs directory exists
    if (system("mkdir -p logs") == -1) {
        fprintf(stderr, "[%s] CRITICAL ERROR: Failed to create 'logs/' directory. Check permissions or disk space. Exiting.\n", get_current_time());
        return 1;
    }

    // Open log files
    log_all_fp = fopen("logs/all_tests.log", "a");
    log_passed_fp = fopen("logs/passed_tests.log", "a");
    log_failed_fp = fopen("logs/failed_tests.log", "a");
    log_crashes_fp = fopen("logs/crashes.log", "a");
    log_missed_opportunities_fp = fopen("logs/missed_opportunities.log", "a");
    log_incorrect_parallelization_fp = fopen("logs/incorrect_parallelization.log", "a");

    if (!log_all_fp || !log_passed_fp || !log_failed_fp || !log_crashes_fp ||
        !log_missed_opportunities_fp || !log_incorrect_parallelization_fp) {
        fprintf(stderr, "[%s] CRITICAL ERROR: One or more log files could not be opened for writing in 'logs/' directory. Check permissions. Exiting.\n", get_current_time());
        // Close any files that were successfully opened before exiting
        if (log_all_fp) fclose(log_all_fp); if (log_passed_fp) fclose(log_passed_fp);
        if (log_failed_fp) fclose(log_failed_fp); if (log_crashes_fp) fclose(log_crashes_fp);
        if (log_missed_opportunities_fp) fclose(log_missed_opportunities_fp); if (log_incorrect_parallelization_fp) fclose(log_incorrect_parallelization_fp);
        return 1;
    }

    // --- Argument Parsing ---
    if (argc < 5) {
        fprintf(stderr, "Usage: %s <mode> <category> <input_file_base_name.c> <expected_behavior>\n", argv[0]);
        fprintf(stderr, "  Modes: compare, generate\n");
        fprintf(stderr, "  Expected_Behavior: parallelize, no_parallelize, expect_failure\n");
        if (log_all_fp) fprintf(log_all_fp, "[%s] ERROR: Insufficient arguments provided. Usage: %s <mode> <category> <input_file.c> <expected_behavior>\n", get_current_time(), argv[0]);
        // Close all logs on error exit
        fclose(log_all_fp); fclose(log_passed_fp); fclose(log_failed_fp); fclose(log_crashes_fp);
        fclose(log_missed_opportunities_fp); fclose(log_incorrect_parallelization_fp); return 1;
    }

    TestMode mode;
    if (strcmp(argv[1], "compare") == 0) { mode = COMPARE_MODE; }
    else if (strcmp(argv[1], "generate") == 0) { mode = GENERATE_MODE; }
    else {
        fprintf(stderr, "Invalid mode: %s. Use 'compare' or 'generate'.\n", argv[1]);
        if (log_all_fp) fprintf(log_all_fp, "[%s] ERROR: Invalid mode provided: %s\n", get_current_time(), argv[1]);
        fclose(log_all_fp); fclose(log_passed_fp); fclose(log_failed_fp); fclose(log_crashes_fp);
        fclose(log_missed_opportunities_fp); fclose(log_incorrect_parallelization_fp); return 1;
    }

    ExpectedParallelization expected_behavior;
    if (strcmp(argv[4], "parallelize") == 0) { expected_behavior = EXPECT_PARALLELIZATION; }
    else if (strcmp(argv[4], "no_parallelize") == 0) { expected_behavior = EXPECT_NO_PARALLELIZATION; }
    else if (strcmp(argv[4], "expect_failure") == 0) { expected_behavior = EXPECT_FAILURE; }
    else {
        fprintf(stderr, "Invalid expected_behavior: %s. Use 'parallelize', 'no_parallelize', or 'expect_failure'.\n", argv[4]);
        if (log_all_fp) fprintf(log_all_fp, "[%s] ERROR: Invalid expected_behavior provided: %s\n", get_current_time(), argv[4]);
        fclose(log_all_fp); fclose(log_passed_fp); fclose(log_failed_fp); fclose(log_crashes_fp);
        fclose(log_missed_opportunities_fp); fclose(log_incorrect_parallelization_fp); return 1;
    }

    const char* category = argv[2];
    const char* input_file_base_name = argv[3];

    printf("[%s] ==== Starting New Test Run ====\n", get_current_time());
    if (log_all_fp) fprintf(log_all_fp, "[%s] ==== Starting New Test Run ====\n", get_current_time());
    printf("[%s] ==== Running tests for category: %s (Mode: %s, Expected: %s) ====\n",
           get_current_time(), category, (mode == COMPARE_MODE ? "compare" : "generate"), argv[4]);
    if (log_all_fp) fprintf(log_all_fp, "[%s] ==== Running tests for category: %s (Mode: %s, Expected: %s) ====\n",
           get_current_time(), category, (mode == COMPARE_MODE ? "compare" : "generate"), argv[4]);

    // --- Execute the Test Case ---
    int test_passed = run_test_case(category, input_file_base_name, mode, expected_behavior);

    // --- Overall Summary ---
    printf("[%s] ==== Overall Test Summary: %d/1 files passed ====\n", get_current_time(), test_passed);
    if (log_all_fp) fprintf(log_all_fp, "[%s] ==== Overall Test Summary: %d/1 files passed ====\n", get_current_time(), test_passed);


    if (test_passed) {
        printf("[%s] ✅ SUCCESS: All tests passed. 🎉\n", get_current_time());
        if (log_all_fp) fprintf(log_all_fp, "[%s] SUCCESS: All tests passed. 🎉\n", get_current_time());
    } else {
        printf("[%s] ❌ ERROR: 💔 Some tests failed. Check the logs and console output for details. 💔\n", get_current_time());
        if (log_all_fp) fprintf(log_all_fp, "[%s] ERROR: 💔 Some tests failed. Check the logs and console output for details. 💔\n", get_current_time());
    }

    // Close all log files
    if (log_all_fp) fclose(log_all_fp);
    if (log_passed_fp) fclose(log_passed_fp);
    if (log_failed_fp) fclose(log_failed_fp);
    if (log_crashes_fp) fclose(log_crashes_fp);
    if (log_missed_opportunities_fp) fclose(log_missed_opportunities_fp);
    if (log_incorrect_parallelization_fp) fclose(log_incorrect_parallelization_fp);

    return test_passed ? 0 : 1; // Return 0 for success, 1 for failure
}